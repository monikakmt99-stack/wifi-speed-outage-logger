# NetPulse — Wi-Fi Speed & Outage Logger

A full-stack Python mini-project that continuously monitors your internet connection, logs speed metrics (Download, Upload, Ping) and network outages into an SQLite database, and displays real-time analytics on a dark-mode web dashboard.

## Project Structure

```text
wifi-speed-outage-logger/
├── app.py                  # Flask web server, REST API & background scheduler
├── monitor.py              # Connectivity checker & speedtest-cli wrapper
├── database.py             # SQLite initialization, queries & sample data seeder
├── requirements.txt        # Python dependencies
├── README.md               # Setup & usage guide
├── data/                   # Auto-created SQLite database directory (wifi_logs.db)
├── templates/
│   └── index.html          # Main dashboard UI template
└── static/
    ├── css/
    │   └── style.css       # Modern glassmorphism dark-mode styling
    └── js/
        └── dashboard.js    # Interactive Chart.js graphs & live API polling
```

## Quick Setup & Run

1. **Extract the ZIP folder** and open a terminal inside `wifi-speed-outage-logger/`.
2. **Create a virtual environment (recommended):**
   ```bash
   python -m venv venv
   # Windows:
   venv\Scripts\activate
   # macOS / Linux:
   source venv/bin/activate
   ```
3. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```
4. **Start the application:**
   ```bash
   python app.py
   ```
5. **Open your browser** and go to:
   `http://127.0.0.1:5000`

## Key Features
- **Automatic Outage Detection:** Performs a fast TCP socket check (`8.8.8.8:53`) before running bandwidth tests so dropped connections are immediately recorded without hanging.
- **Background Scheduler:** Runs automatically every 10 minutes (adjustable from 1 min to 1 hour directly from the UI, with Pause/Resume controls).
- **Interactive Analytics:** Real-time bandwidth timeline with red outage markers, uptime percentage, peak speeds, and latency tracking.
- **CSV Export:** Download your complete ISP performance log in one click to share with your broadband provider.
