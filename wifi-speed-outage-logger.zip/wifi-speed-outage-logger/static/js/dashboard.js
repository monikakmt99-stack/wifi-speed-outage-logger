let speedChart = null;
let isPaused = false;

function showToast(message) {
    const toast = document.getElementById("toast");
    toast.textContent = message;
    toast.classList.add("show");
    setTimeout(() => toast.classList.remove("show"), 3500);
}

function initChart() {
    const ctx = document.getElementById("speedChart").getContext("2d");

    const dlGradient = ctx.createLinearGradient(0, 0, 0, 300);
    dlGradient.addColorStop(0, "rgba(6, 182, 212, 0.35)");
    dlGradient.addColorStop(1, "rgba(6, 182, 212, 0.0)");

    const ulGradient = ctx.createLinearGradient(0, 0, 0, 300);
    ulGradient.addColorStop(0, "rgba(139, 92, 246, 0.28)");
    ulGradient.addColorStop(1, "rgba(139, 92, 246, 0.0)");

    speedChart = new Chart(ctx, {
        type: "line",
        data: {
            labels: [],
            datasets: [
                {
                    label: "Download (Mbps)",
                    data: [],
                    borderColor: "#06b6d4",
                    backgroundColor: dlGradient,
                    borderWidth: 2.5,
                    tension: 0.35,
                    fill: true,
                    pointRadius: 4,
                    pointHoverRadius: 6
                },
                {
                    label: "Upload (Mbps)",
                    data: [],
                    borderColor: "#8b5cf6",
                    backgroundColor: ulGradient,
                    borderWidth: 2,
                    tension: 0.35,
                    fill: true,
                    pointRadius: 3,
                    pointHoverRadius: 5
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: "index",
                intersect: false
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: "#0f172a",
                    titleColor: "#f8fafc",
                    bodyColor: "#cbd5e1",
                    borderColor: "rgba(148, 163, 184, 0.2)",
                    borderWidth: 1,
                    padding: 12
                }
            },
            scales: {
                x: {
                    grid: { color: "rgba(148, 163, 184, 0.08)" },
                    ticks: { color: "#94a3b8", maxTicksLimit: 10 }
                },
                y: {
                    beginAtZero: true,
                    grid: { color: "rgba(148, 163, 184, 0.08)" },
                    ticks: {
                        color: "#94a3b8",
                        callback: (val) => `${val} Mbps`
                    }
                }
            }
        }
    });
}

async function fetchDashboardData() {
    try {
        const res = await fetch("/api/dashboard?limit=30");
        const data = await res.json();
        updateKPIs(data.stats);
        updateChart(data.logs);
        updateTable(data.logs);
        updateSchedulerUI(data.scheduler_paused);
        setTestingState(data.is_testing);
    } catch (err) {
        console.error("Failed to fetch dashboard data:", err);
    }
}

function updateKPIs(stats) {
    document.getElementById("avgDownload").textContent = stats.avg_download.toFixed(1);
    document.getElementById("maxDownload").textContent = `${stats.max_download.toFixed(1)} Mbps`;
    document.getElementById("avgUpload").textContent = stats.avg_upload.toFixed(1);
    document.getElementById("avgPing").textContent = stats.avg_ping.toFixed(1);
    document.getElementById("uptimePercent").textContent = `${stats.uptime_percent}%`;
    document.getElementById("outageCount").textContent = stats.outages;
    document.getElementById("totalChecks").textContent = stats.total_checks;

    const banner = document.getElementById("statusBanner");
    const badge = document.getElementById("statusBadge");
    const msg = document.getElementById("statusMessage");
    const ispLabel = document.getElementById("ispLabel");
    const lastChecked = document.getElementById("lastCheckedLabel");

    if (stats.latest) {
        document.getElementById("latestUpload").textContent = `${stats.latest.upload_mbps.toFixed(1)} Mbps`;
        document.getElementById("latestPing").textContent = `${stats.latest.ping_ms.toFixed(1)} ms`;
        ispLabel.textContent = `ISP: ${stats.latest.isp}`;
        lastChecked.textContent = `Last check: ${stats.latest.timestamp}`;

        if (stats.latest.status === "OUTAGE") {
            banner.className = "status-banner outage";
            badge.textContent = "OUTAGE DETECTED";
            msg.textContent = `Connection dropped (${stats.latest.notes})`;
        } else {
            banner.className = "status-banner online";
            badge.textContent = "ONLINE";
            msg.textContent = `Healthy (${stats.latest.download_mbps} Mbps Down / ${stats.latest.ping_ms} ms Ping)`;
        }
    }
}

function updateChart(logs) {
    if (!speedChart) return;
    // Reverse so chronological left-to-right
    const chronological = [...logs].reverse();

    const labels = chronological.map(item => item.timestamp.split(" ")[1] || item.timestamp);
    const dlData = chronological.map(item => item.download_mbps);
    const ulData = chronological.map(item => item.upload_mbps);
    const pointColors = chronological.map(item => item.status === "OUTAGE" ? "#ef4444" : "#06b6d4");
    const pointRadii = chronological.map(item => item.status === "OUTAGE" ? 6 : 3.5);

    speedChart.data.labels = labels;
    speedChart.data.datasets[0].data = dlData;
    speedChart.data.datasets[0].pointBackgroundColor = pointColors;
    speedChart.data.datasets[0].pointBorderColor = pointColors;
    speedChart.data.datasets[0].pointRadius = pointRadii;
    speedChart.data.datasets[1].data = ulData;
    speedChart.update("none");
}

function updateTable(logs) {
    const tbody = document.getElementById("logsTableBody");
    if (!logs || logs.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" class="empty-state">No diagnostic records yet. Click "Run Speed Test" to begin.</td></tr>`;
        return;
    }

    tbody.innerHTML = logs.map(row => {
        const isOutage = row.status === "OUTAGE";
        const badgeClass = isOutage ? "pill-outage" : "pill-online";
        return `
            <tr>
                <td class="mono">${row.timestamp}</td>
                <td><span class="pill ${badgeClass}">${row.status}</span></td>
                <td class="mono">${row.download_mbps.toFixed(2)} Mbps</td>
                <td class="mono">${row.upload_mbps.toFixed(2)} Mbps</td>
                <td class="mono">${row.ping_ms.toFixed(1)} ms</td>
                <td>${row.isp}</td>
                <td style="color: var(--text-secondary)">${row.notes || "-"}</td>
            </tr>
        `;
    }).join("");
}

function updateSchedulerUI(paused) {
    isPaused = paused;
    const btnText = document.getElementById("schedulerBtnText");
    btnText.textContent = paused ? "Resume Auto" : "Pause Auto";
}

function setTestingState(testing) {
    const btn = document.getElementById("runTestBtn");
    const spinner = document.getElementById("testSpinner");
    const text = document.getElementById("runTestText");

    btn.disabled = testing;
    if (testing) {
        spinner.classList.add("active");
        text.textContent = "Testing Speed...";
    } else {
        spinner.classList.remove("active");
        text.textContent = "Run Speed Test";
    }
}

document.addEventListener("DOMContentLoaded", () => {
    initChart();
    fetchDashboardData();

    // Auto-refresh UI every 15 seconds
    setInterval(fetchDashboardData, 15000);

    // Manual Speed Test
    document.getElementById("runTestBtn").addEventListener("click", async () => {
        setTestingState(true);
        showToast("Running live speed & latency test (~15-20s)...");
        try {
            const res = await fetch("/api/run-test", { method: "POST" });
            const data = await res.json();
            if (data.status === "ONLINE") {
                showToast(`Test complete: ${data.download_mbps} Mbps Down / ${data.upload_mbps} Mbps Up`);
            } else if (data.status === "OUTAGE") {
                showToast("Warning: Internet outage logged!");
            } else {
                showToast(data.message || "Test already running.");
            }
        } catch (err) {
            showToast("Error communicating with local server.");
        } finally {
            setTestingState(false);
            fetchDashboardData();
        }
    });

    // Pause / Resume Background Scheduler
    document.getElementById("toggleSchedulerBtn").addEventListener("click", async () => {
        const action = isPaused ? "resume" : "pause";
        const res = await fetch("/api/scheduler", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action })
        });
        const data = await res.json();
        showToast(data.message || "Updated monitor state");
        fetchDashboardData();
    });

    // Update Auto-Check Interval
    document.getElementById("intervalSelect").addEventListener("change", async (e) => {
        const minutes = parseInt(e.target.value, 10);
        const res = await fetch("/api/scheduler", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ minutes })
        });
        const data = await res.json();
        showToast(data.message || "Interval updated");
    });

    // Clear Logs
    document.getElementById("clearLogsBtn").addEventListener("click", async () => {
        if (!confirm("Clear all historical speed and outage records?")) return;
        await fetch("/api/clear", { method: "POST" });
        showToast("History cleared.");
        fetchDashboardData();
    });
});
