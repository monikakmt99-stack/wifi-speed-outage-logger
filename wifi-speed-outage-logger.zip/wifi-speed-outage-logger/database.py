import sqlite3
import os
from datetime import datetime, timedelta

DB_PATH = os.path.join(os.path.dirname(__file__), "data", "wifi_logs.db")


def get_connection():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS speed_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            status TEXT NOT NULL,
            download_mbps REAL DEFAULT 0.0,
            upload_mbps REAL DEFAULT 0.0,
            ping_ms REAL DEFAULT 0.0,
            isp TEXT DEFAULT 'Unknown',
            server_name TEXT DEFAULT 'N/A',
            notes TEXT DEFAULT ''
        )
    """)
    conn.commit()
    conn.close()


def insert_log(status, download_mbps=0.0, upload_mbps=0.0, ping_ms=0.0, isp="Unknown", server_name="N/A", notes=""):
    conn = get_connection()
    cursor = conn.cursor()
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute("""
        INSERT INTO speed_logs (timestamp, status, download_mbps, upload_mbps, ping_ms, isp, server_name, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (timestamp, status, round(download_mbps, 2), round(upload_mbps, 2), round(ping_ms, 2), isp, server_name, notes))
    conn.commit()
    log_id = cursor.lastrowid
    conn.close()
    return log_id


def get_recent_logs(limit=50):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM speed_logs ORDER BY id DESC LIMIT ?", (limit,))
    rows = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return rows


def get_all_logs():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM speed_logs ORDER BY id ASC")
    rows = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return rows


def get_stats():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) as total FROM speed_logs")
    total = cursor.fetchone()["total"]

    if total == 0:
        conn.close()
        return {
            "total_checks": 0,
            "uptime_percent": 100.0,
            "outages": 0,
            "avg_download": 0.0,
            "avg_upload": 0.0,
            "avg_ping": 0.0,
            "max_download": 0.0,
            "latest": None
        }

    cursor.execute("SELECT COUNT(*) as online_count FROM speed_logs WHERE status = 'ONLINE'")
    online_count = cursor.fetchone()["online_count"]
    outages = total - online_count
    uptime_percent = round((online_count / total) * 100, 1)

    cursor.execute("""
        SELECT
            AVG(download_mbps) as avg_dl,
            AVG(upload_mbps) as avg_ul,
            AVG(ping_ms) as avg_ping,
            MAX(download_mbps) as max_dl
        FROM speed_logs
        WHERE status = 'ONLINE'
    """)
    agg = cursor.fetchone()

    cursor.execute("SELECT * FROM speed_logs ORDER BY id DESC LIMIT 1")
    latest_row = cursor.fetchone()
    latest = dict(latest_row) if latest_row else None

    conn.close()
    return {
        "total_checks": total,
        "uptime_percent": uptime_percent,
        "outages": outages,
        "avg_download": round(agg["avg_dl"] or 0.0, 2),
        "avg_upload": round(agg["avg_ul"] or 0.0, 2),
        "avg_ping": round(agg["avg_ping"] or 0.0, 2),
        "max_download": round(agg["max_dl"] or 0.0, 2),
        "latest": latest
    }


def clear_logs():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM speed_logs")
    conn.commit()
    conn.close()


def seed_sample_data():
    """Populates realistic sample data if the database is completely empty so the dashboard looks alive immediately."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) as cnt FROM speed_logs")
    if cursor.fetchone()["cnt"] > 0:
        conn.close()
        return

    now = datetime.now()
    sample_entries = [
        (-110, "ONLINE", 94.5, 48.2, 12.4, "JioFiber / Airtel Xstream", "Mumbai - Server 1", "Scheduled check"),
        (-100, "ONLINE", 91.2, 46.8, 14.1, "JioFiber / Airtel Xstream", "Mumbai - Server 1", "Scheduled check"),
        (-90,  "ONLINE", 88.7, 45.0, 15.8, "JioFiber / Airtel Xstream", "Mumbai - Server 1", "Scheduled check"),
        (-80,  "OUTAGE", 0.0,  0.0,  0.0,  "Disconnected",             "N/A",               "Request timed out / No internet"),
        (-70,  "OUTAGE", 0.0,  0.0,  0.0,  "Disconnected",             "N/A",               "DNS resolution failed"),
        (-60,  "ONLINE", 76.4, 39.5, 22.0, "JioFiber / Airtel Xstream", "Mumbai - Server 2", "Connection restored"),
        (-50,  "ONLINE", 92.8, 49.1, 11.9, "JioFiber / Airtel Xstream", "Mumbai - Server 1", "Scheduled check"),
        (-40,  "ONLINE", 96.1, 50.4, 10.8, "JioFiber / Airtel Xstream", "Mumbai - Server 1", "Scheduled check"),
        (-30,  "ONLINE", 85.3, 42.7, 16.5, "JioFiber / Airtel Xstream", "Mumbai - Server 1", "Scheduled check"),
        (-20,  "ONLINE", 93.9, 47.9, 13.2, "JioFiber / Airtel Xstream", "Mumbai - Server 1", "Scheduled check"),
        (-10,  "ONLINE", 95.4, 49.8, 11.5, "JioFiber / Airtel Xstream", "Mumbai - Server 1", "Scheduled check"),
    ]

    for mins_ago, status, dl, ul, ping, isp, srv, notes in sample_entries:
        ts = (now + timedelta(minutes=mins_ago)).strftime("%Y-%m-%d %H:%M:%S")
        cursor.execute("""
            INSERT INTO speed_logs (timestamp, status, download_mbps, upload_mbps, ping_ms, isp, server_name, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (ts, status, dl, ul, ping, isp, srv, notes))

    conn.commit()
    conn.close()
