import socket
import threading
import speedtest
from database import insert_log

test_lock = threading.Lock()
is_running_test = False


def check_internet_connectivity(host="8.8.8.8", port=53, timeout=3):
    """Fast TCP check to verify basic internet connectivity before running a heavy speedtest."""
    try:
        socket.setdefaulttimeout(timeout)
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.connect((host, port))
        return True
    except OSError:
        return False


def run_network_check(trigger="Scheduled check"):
    """Runs a full speed test or logs an outage if offline. Thread-safe."""
    global is_running_test
    if not test_lock.acquire(blocking=False):
        return {"status": "BUSY", "message": "A speed test is already in progress."}

    is_running_test = True
    try:
        if not check_internet_connectivity():
            insert_log(
                status="OUTAGE",
                download_mbps=0.0,
                upload_mbps=0.0,
                ping_ms=0.0,
                isp="Disconnected",
                server_name="N/A",
                notes=f"{trigger} - No internet connection detected"
            )
            return {
                "status": "OUTAGE",
                "download_mbps": 0.0,
                "upload_mbps": 0.0,
                "ping_ms": 0.0,
                "notes": "Internet outage detected!"
            }

        st = speedtest.Speedtest(secure=True)
        st.get_best_server()
        download_bps = st.download()
        upload_bps = st.upload()
        results = st.results.dict()

        download_mbps = download_bps / 1_000_000
        upload_mbps = upload_bps / 1_000_000
        ping_ms = results.get("ping", 0.0)
        isp = results.get("client", {}).get("isp", "Unknown ISP")
        server_info = results.get("server", {})
        server_name = f"{server_info.get('sponsor', 'Server')} ({server_info.get('name', '')})".strip()

        insert_log(
            status="ONLINE",
            download_mbps=download_mbps,
            upload_mbps=upload_mbps,
            ping_ms=ping_ms,
            isp=isp,
            server_name=server_name,
            notes=trigger
        )

        return {
            "status": "ONLINE",
            "download_mbps": round(download_mbps, 2),
            "upload_mbps": round(upload_mbps, 2),
            "ping_ms": round(ping_ms, 2),
            "isp": isp,
            "server_name": server_name
        }

    except Exception as exc:
        insert_log(
            status="OUTAGE",
            download_mbps=0.0,
            upload_mbps=0.0,
            ping_ms=0.0,
            isp="Error / Timeout",
            server_name="N/A",
            notes=f"{trigger} - {str(exc)[:80]}"
        )
        return {
            "status": "OUTAGE",
            "download_mbps": 0.0,
            "upload_mbps": 0.0,
            "ping_ms": 0.0,
            "notes": f"Test failed: {exc}"
        }
    finally:
        is_running_test = False
        test_lock.release()
