import csv
import io
import os
from flask import Flask, render_template, jsonify, request, Response
from apscheduler.schedulers.background import BackgroundScheduler
from database import init_db, get_recent_logs, get_all_logs, get_stats, clear_logs, seed_sample_data
from monitor import run_network_check, is_running_test

app = Flask(__name__)

# Initialize SQLite database and populate sample data if brand new
init_db()
seed_sample_data()

# Background scheduler configuration
DEFAULT_INTERVAL_MINUTES = 10
scheduler = BackgroundScheduler(daemon=True)
scheduler.add_job(
    func=lambda: run_network_check(trigger="Auto-scheduled check"),
    trigger="interval",
    minutes=DEFAULT_INTERVAL_MINUTES,
    id="wifi_monitor_job",
    replace_existing=True
)
scheduler.start()


@app.route("/")
def index():
    return render_template("index.html", interval=DEFAULT_INTERVAL_MINUTES)


@app.route("/api/dashboard")
def api_dashboard():
    limit = request.args.get("limit", default=30, type=int)
    stats = get_stats()
    logs = get_recent_logs(limit=limit)
    job = scheduler.get_job("wifi_monitor_job")
    is_paused = job.next_run_time is None if job else True
    return jsonify({
        "stats": stats,
        "logs": logs,
        "is_testing": is_running_test,
        "scheduler_paused": is_paused
    })


@app.route("/api/run-test", methods=["POST"])
def api_run_test():
    result = run_network_check(trigger="Manual test")
    status_code = 409 if result.get("status") == "BUSY" else 200
    return jsonify(result), status_code


@app.route("/api/scheduler", methods=["POST"])
def api_scheduler():
    data = request.get_json(silent=True) or {}
    action = data.get("action")
    minutes = data.get("minutes")

    job = scheduler.get_job("wifi_monitor_job")
    if not job:
        return jsonify({"error": "Scheduler job not found"}), 404

    if action == "pause":
        scheduler.pause_job("wifi_monitor_job")
        return jsonify({"message": "Auto-monitoring paused", "paused": True})
    elif action == "resume":
        scheduler.resume_job("wifi_monitor_job")
        return jsonify({"message": "Auto-monitoring resumed", "paused": False})
    elif minutes and isinstance(minutes, int) and 1 <= minutes <= 1440:
        scheduler.reschedule_job("wifi_monitor_job", trigger="interval", minutes=minutes)
        return jsonify({"message": f"Interval updated to every {minutes} min", "minutes": minutes})

    return jsonify({"error": "Invalid scheduler command"}), 400


@app.route("/api/clear", methods=["POST"])
def api_clear():
    clear_logs()
    return jsonify({"message": "All logs cleared successfully"})


@app.route("/api/export.csv")
def export_csv():
    logs = get_all_logs()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ID", "Timestamp", "Status", "Download (Mbps)", "Upload (Mbps)", "Ping (ms)", "ISP", "Server", "Notes"])
    for row in logs:
        writer.writerow([
            row["id"],
            row["timestamp"],
            row["status"],
            row["download_mbps"],
            row["upload_mbps"],
            row["ping_ms"],
            row["isp"],
            row["server_name"],
            row["notes"]
        ])
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment;filename=wifi_speed_outage_report.csv"}
    )


if __name__ == "__main__":
    # use_reloader=False prevents APScheduler from running duplicate background jobs in debug mode
    app.run(host="0.0.0.0", port=5000, debug=True, use_reloader=False)
